/* esm.sh - react@19.2.3 */
export * from "/react@19.2.3/es2022/react.mjs";
export { default } from "/react@19.2.3/es2022/react.mjs";
